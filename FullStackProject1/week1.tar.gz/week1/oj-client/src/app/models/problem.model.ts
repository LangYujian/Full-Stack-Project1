export class Problem{
  id: number;
  name: string;
  description: string;
  difficulty: string;
}
